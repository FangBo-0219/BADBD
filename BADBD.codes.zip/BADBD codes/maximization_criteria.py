


# Several existing maximization criteria


import numpy as np
import pylab as pl
import tensorflow as tf
from scipy import fftpack


#    Parameter introduction
#   halfFilterlength : Half the length of the filter. Used to ignore the filter length in the convolution operation
#   T : fault period.   fs/FCF

# kurtosis
def funcKurtosis(y, halfFilterlength):
    y_1 = tf.squeeze(y)
    y_1 = y_1[halfFilterlength:-halfFilterlength]
    y_2 = y_1 - tf.reduce_mean(y_1)
    num = len(y_2)
    y_num = tf.reduce_sum(tf.pow(y_2, 4)) / num
    std = tf.sqrt(tf.reduce_sum(tf.pow(y_2, 2)) / num)
    y_dem = tf.pow(std, 4)
    loss = y_num / y_dem
    return loss


# D_norm
def funcD_norm(y, halfFilterlength):
    y_1 = tf.squeeze(y)
    y_1 = y_1[halfFilterlength:-halfFilterlength]
    y_2 = y_1 - tf.reduce_mean(y_1)
    y_abs = tf.math.abs(y_2)
    y_max = tf.reduce_max(y_abs)
    y_D_norm = tf.norm(y_abs, 2)
    D_norm = y_max / y_D_norm
    loss = D_norm

    return loss


# correlated kurtosis  M=1
def funcCorrelatedKurtosisM1(y, T, halfFilterlength):
    y_1 = tf.squeeze(y)
    y_1 = y_1[halfFilterlength:-halfFilterlength]
    y_2 = y_1 - tf.reduce_mean(y_1)
    num1 = len(y_2)
    y_2_1 = y_2[:num1 - T]
    y_2_2 = y_2[T:num1]

    y_num = tf.reduce_sum(tf.square(tf.multiply(y_2_1, y_2_2)))
    y_dem = tf.square(tf.reduce_sum(tf.square(y_2_1)))
    loss = y_num / y_dem
    return loss


# correlated kurtosis  M=2
def funcCorrelatedKurtosisM2(y, T, halfFilterlength):
    y_1 = tf.squeeze(y)
    y_1 = y_1[halfFilterlength:-halfFilterlength]
    y_2 = y_1 - tf.reduce_mean(y_1)
    num1 = len(y_2)
    y_2_1 = y_2[: num1 - 2 * T]
    y_2_2 = y_2[T: num1 - T]
    y_2_3 = y_2[2 * T: num1]
    temp1 = tf.math.multiply(y_2_1, y_2_2)
    temp2 = tf.math.multiply(temp1, y_2_3)

    y_num = tf.reduce_sum(tf.square(temp2))
    y_dem = tf.math.pow(tf.reduce_sum(tf.square(y_2_1)), 3)
    loss = y_num / y_dem
    return loss


# Impulse-Norm
def funcImpulseNorm(y, percent, halfFilterlength):
    y_1 = tf.squeeze(y)
    y_1 = y_1[halfFilterlength:-halfFilterlength]
    y_1 = y_1 - tf.reduce_mean(y_1)
    y_2 = tf.math.abs(y_1)
    num = len(y_2)
    num2 = tf.dtypes.cast(tf.math.round(num * percent), tf.int32)
    y_2_s = tf.sort(y_2, direction='DESCENDING')

    y_num = tf.reduce_sum(y_2_s[0:num2])
    y_dem = tf.norm(y_2_s, ord='euclidean')
    loss = y_num / (y_dem * tf.dtypes.cast(num2, tf.float32))
    return loss


# Gini
def funcGini(y, halfFilterlength):
    y_1 = tf.math.abs(tf.squeeze(y))
    y_1 = y_1[halfFilterlength: -halfFilterlength]
    N = len(y_1)
    Sum = tf.reduce_sum(y_1)
    Weights = y_1 / Sum
    Weights = tf.sort(Weights)
    ProportionValue = tf.math.cumsum(Weights)
    sum_2 = tf.reduce_sum(2 * ProportionValue) / N
    Gini = 1 - sum_2
    return Gini


# Multi D_norm.  Need to specify a larger filter length
def funcMultiD_norm(y, T, halfFilterlength):
    y_1 = tf.squeeze(y)
    y_1 = y_1[halfFilterlength:-halfFilterlength]
    y_2 = y_1 - tf.reduce_mean(y_1)
    y_3 = y_2[0:-1:T]
    loss = tf.reduce_sum(y_3) / tf.norm(y_2, 2)
    return loss


# Envelope spectrum
def funcEnv_Es(signal_pp, Title1, Fs, SignalLim, EsLim):
    a_signal_raw = fftpack.hilbert(signal_pp)
    hx_raw_abs = abs(a_signal_raw)
    hx_raw_abs1 = hx_raw_abs - np.mean(hx_raw_abs)
    es_raw = fftpack.fft(hx_raw_abs1, len(signal_pp))
    es_raw_abs = abs(es_raw)

    t1 = (np.arange(0, len(signal_pp))) / Fs

    f1 = t1 * Fs * Fs / len(signal_pp)

    pl.figure()
    pl.subplot(211)
    pl.plot(t1, signal_pp, label=u"raw signal")
    pl.xlim(SignalLim)
    pl.title(Title1)
    pl.subplot(212)
    pl.plot(f1, es_raw_abs)
    pl.xlabel('Envelope spectrum')
    pl.xlim(EsLim)


# Spectrum
def funcSpectrum_freq(signal, fs, Title):
    N = len(signal)
    f = np.arange(0, N) / N * fs
    mag = fftpack.fft(signal)
    mag = abs(mag)
    pl.figure()
    pl.plot(f, mag)
    pl.xlim([0, fs / 2])
    pl.title(Title)
