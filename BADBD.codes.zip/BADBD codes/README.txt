
Provided by    Bo Fang   2021.11.25.       FangBooo@outlook.com


# Related article:
 A blind deconvolution algorithm based on backward automatic differentiation and its application to rolling bearing fault diagnosis


The operating environment is based on tensorflow2.1 GPU, and the Python interpreter needs to be configured. 



