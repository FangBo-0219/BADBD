

#  The  code of BADBD
# Provided by    Bo Fang   2021.11.25.
# Related article:
# A blind deconvolution algorithm based on backward automatic differentiation and its application to rolling bearing fault diagnosis

# Environmental : TensorFlow2.1 GPU.
# More tests are done in MATLAB.
#  CPU:8300HQ   GPU:1050Ti

# The implements of MED,MCKD,OMED MOMEDA can be downloaded  from the MATLAB community.
# https://ww2.mathworks.cn/matlabcentral/fileexchange/53484-minimum-entropy-deconvolution-multipack-med-meda-omeda-momeda-mckd

# The datasets are provided by Case Western Reserve University (CWRU) bearing data website
# https://csegroups.case.edu/bearingdatacenter/pages/welcome-case-western-reserve-university-bearing-data-center-website.

# Both ends of the filtered signal are affected by the filter and should be removed.

import time
import tensorflow as tf
import numpy as np
import pylab as pl
import maximization_criteria as MC

# -----------------------------------------------------Parameter assignment----------------------------------------
num = 1200 * 4  # Signal length
filterLen = 40  # Filter length
fs = 12000  # Sampling frequency
learningRate = 0.01  # Learning rate
iter = 300  # Maximum number of iterations    100 150 300 500

layersNum = 2  # Number of deconvolution filter layers   ====================key parameter===========================
TestNum = 2  # Number of tests

optimizer = tf.optimizers.Adam(learningRate)  # ADAM optimizer


# Data loading The datasets are provided by Case Western Reserve University (CWRU) bearing data website
file = 'X105_BA_time.txt'
signal = []
for line in open(file, "r"):
    point = float(line)
    signal.append(point)
signal_1 = signal[0: 0 + num]
signal_f = tf.cast(signal_1, dtype=tf.float32)
signal_r = tf.reshape(signal_f, [1, num, 1])


# Deconvolution filter layer
def conv1d(x, W):
    x = tf.nn.conv2d(x, W, strides=[1, 1, 1, 1], padding='SAME')
    return x


#  Filter coefficients initialization
random_normal = tf.initializers.RandomNormal()
coeffs = {}
for i in range(layersNum):
    layerName = 'wc%d' % (i + 1)
    coeffs[layerName] = tf.Variable(random_normal([filterLen, 1, 1, 1]))


# BADBD forward
def BADBDForward(x):
    # reshape
    x = tf.reshape(x, [1, num, 1, 1])
    conv1 = x
    for i in range(layersNum):
        conv1 = conv1d(conv1, coeffs['wc%d' % (i + 1)])
    return conv1


# Single iteration
def run_optimization(x):
    with tf.GradientTape() as g:
        y = BADBDForward(x)
        #  --------------------------------------------------Objective function selection -----------------------------------------------------
        loss = -MC.funcKurtosis(y, tf.dtypes.cast(filterLen / 2, tf.int32))  # Minimize the opposite of kurtosis;
        #loss = -MC.funcImpulseNorm(y,0.005 ,tf.dtypes.cast(filterLen / 2, tf.int32))  # Minimize the opposite of Impulse-Norm;
        #loss = -MC.funcCorrelatedKurtosisM1(y, 75,tf.dtypes.cast(filterLen / 2, tf.int32))  # Minimize the opposite of Correlated Kurtosis   M=2
        #loss = -MC.funcD_norm(y, tf.dtypes.cast(filterLen / 2, tf.int32))
        #loss = -MC.funcGini(y, tf.dtypes.cast(filterLen / 2, tf.int32))
        #loss = -MC.funcMultiD_norm(y,75, tf.dtypes.cast(filterLen / 2, tf.int32))
    trainable_variables = list(coeffs.values())
    gradients = g.gradient(loss, trainable_variables)
    optimizer.apply_gradients(zip(gradients, trainable_variables))
    return y, loss

# Save the target function value for each iteration
VectorObj = np.empty([TestNum, iter + 1])
signalFiltered = np.empty([TestNum, len(signal_1)])  # len(signal_1)
Weights = []

# Time starts
start = time.time()
#  iterative process
for n in range(TestNum):
    for step in range(iter + 1):
        y_out, loss = run_optimization(signal_r)
        VectorObj[n, step] = -loss
    signalFiltered[n, :] = tf.squeeze(y_out)

    Weights.append(coeffs)  # Save the coeffs of each test

    for i in coeffs.keys():
        coeffs[i] = tf.Variable(random_normal([filterLen, 1, 1, 1]))

# The clock is over
run_time = time.time() - start

# Save coeffs.  You can view the filter coefficients of all tests
# WeightsArray[testNum, layersNum, filterLen] :
# testNum = Number of tests；
# layersNum = Number of deconvolution filter layers ；
# filterLen = Filter length
WeightsArray = np.empty([TestNum, layersNum, filterLen])
for i in range(len(Weights)):
    temp = Weights[i]
    for j in range(layersNum):
        layerName = 'wc%d' % (j + 1)
        temp2 = tf.squeeze(temp.get(layerName))
        WeightsArray[i, j, :] = temp2

print("========================= Results ===========================")
print("Running time of the iterative process:", np.round(run_time,4))

if type(signal_1) != list:
    signal_1_n = signal_1.numpy()
else:
    signal_1_n = signal_1


print("The objective function values for all tests:", VectorObj[:, iter])
print("The average values of objective function:", tf.reduce_mean(VectorObj[:, iter]))

for i in range(TestNum):
    MC.funcEnv_Es(signalFiltered[i, :], 'BADBD filtered signal', fs, [0, 4800 / fs], [0, 1000])
    pl.figure()
    pl.plot(VectorObj[i, :], 'b')
    pl.xlabel('iteration-%d' % i)
    pl.ylabel('Loss')

# Raw signal
MC.funcEnv_Es(signal_1_n, 'Raw signal', fs, [0, 4800 / fs], [0, 1000])

pl.show()
